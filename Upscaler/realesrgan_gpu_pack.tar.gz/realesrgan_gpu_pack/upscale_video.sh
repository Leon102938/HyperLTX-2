#!/usr/bin/env bash
set -euo pipefail

log()  { printf '[%s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*"; }
warn() { printf '[%s] WARN: %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*" >&2; }
err()  { printf '[%s] ERROR: %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*" >&2; }

usage() {
  cat <<'EOF'
Usage:
  ./upscale_video.sh --in input.mp4 --out output.mp4 [--scale 2|4] [--model realesrgan-x4plus|realesrgan-x4plus-anime] [--target 1080x1920] [--tile 256] [--gpu-id 0] [--allow-cpu] [--keep-frames]

Defaults:
  --scale 2
  --model realesrgan-x4plus
  --tile 256
  --target 1080x1920

Notes:
  - Use --target none for pure x2/x4 output dimensions without canvas resize.
  - GPU-only is enforced by default. Use --allow-cpu only for debugging.
  - If Vulkan is broken but CUDA/NVENC is available, script uses a GPU CUDA fallback scaler.
EOF
}

require_arg() {
  local key="$1"
  local val="${2:-}"
  [[ -n "$val" ]] || { err "$key requires a value"; exit 1; }
}

run_cuda_fallback() {
  local input="$1"
  local output="$2"
  local scale="$3"
  local target="$4"
  local has_audio="$5"

  command -v ffmpeg >/dev/null 2>&1 || { err "ffmpeg not found for CUDA fallback"; return 1; }
  FFMPEG_FILTERS="$(ffmpeg -hide_banner -filters 2>/dev/null || true)"
  FFMPEG_ENCODERS="$(ffmpeg -hide_banner -encoders 2>/dev/null || true)"
  echo "$FFMPEG_FILTERS" | grep -q ' scale_cuda ' || { err "ffmpeg scale_cuda filter not available"; return 1; }
  echo "$FFMPEG_ENCODERS" | grep -q 'h264_nvenc' || { err "ffmpeg h264_nvenc encoder not available"; return 1; }

  local in_w in_h out_w out_h
  in_w="$(ffprobe -v error -select_streams v:0 -show_entries stream=width -of csv=p=0 "$input")"
  in_h="$(ffprobe -v error -select_streams v:0 -show_entries stream=height -of csv=p=0 "$input")"
  [[ -n "$in_w" && -n "$in_h" ]] || { err "Could not detect input dimensions"; return 1; }

  if [[ -n "$target" ]]; then
    out_w="${target%x*}"
    out_h="${target#*x}"
  else
    out_w=$(( in_w * scale ))
    out_h=$(( in_h * scale ))
  fi

  # NVENC expects even dimensions.
  out_w=$(( (out_w / 2) * 2 ))
  out_h=$(( (out_h / 2) * 2 ))
  [[ "$out_w" -ge 2 && "$out_h" -ge 2 ]] || { err "Computed output dimensions are invalid: ${out_w}x${out_h}"; return 1; }

  log "CUDA fallback active: scale_cuda ${in_w}x${in_h} -> ${out_w}x${out_h}"

  if [[ "$has_audio" == "1" ]]; then
    ffmpeg -hide_banner -loglevel error -y \
      -hwaccel cuda -hwaccel_output_format cuda \
      -i "$input" \
      -map 0:v:0 -map 0:a:0 \
      -vf "scale_cuda=w=${out_w}:h=${out_h}:interp_algo=lanczos" \
      -c:v h264_nvenc -preset p6 -tune hq -cq 16 -b:v 0 \
      -c:a copy -shortest \
      "$output"
  else
    ffmpeg -hide_banner -loglevel error -y \
      -hwaccel cuda -hwaccel_output_format cuda \
      -i "$input" \
      -map 0:v:0 \
      -vf "scale_cuda=w=${out_w}:h=${out_h}:interp_algo=lanczos" \
      -c:v h264_nvenc -preset p6 -tune hq -cq 16 -b:v 0 \
      "$output"
  fi

  [[ -f "$output" ]] || { err "CUDA fallback did not create output: $output"; return 1; }
  log "CUDA fallback done: $output"
  return 0
}

INPUT=""
OUTPUT=""
SCALE="2"
MODEL="realesrgan-x4plus"
TARGET="1080x1920"
TILE="256"
KEEP_FRAMES="0"
GPU_ID="0"
USER_GPU_ID_SET="0"
REQUIRE_GPU="1"

TOOLS_DIR="/workspace/tools/realesrgan"
MODELS_DIR="${TOOLS_DIR}/models"
REALESRGAN_BIN="/usr/local/bin/realesrgan-ncnn-vulkan"

# Avoid shader-cache permission issues in containerized environments.
export XDG_CACHE_HOME="${XDG_CACHE_HOME:-/tmp/.cache_realesrgan}"
mkdir -p "$XDG_CACHE_HOME"
export XDG_RUNTIME_DIR="${XDG_RUNTIME_DIR:-/tmp/xdg-runtime-root}"
mkdir -p "$XDG_RUNTIME_DIR"
chmod 700 "$XDG_RUNTIME_DIR" 2>/dev/null || true

# Some container setups expose only /dev/nvidia1; add alias for tooling expecting /dev/nvidia0.
if [[ ! -e /dev/nvidia0 && -e /dev/nvidia1 ]]; then
  ln -sf /dev/nvidia1 /dev/nvidia0 2>/dev/null || true
fi

if [[ $# -eq 0 ]]; then
  usage
  exit 1
fi

while [[ $# -gt 0 ]]; do
  case "$1" in
    --in)
      require_arg "$1" "${2:-}"; INPUT="$2"; shift 2 ;;
    --out)
      require_arg "$1" "${2:-}"; OUTPUT="$2"; shift 2 ;;
    --scale)
      require_arg "$1" "${2:-}"; SCALE="$2"; shift 2 ;;
    --model)
      require_arg "$1" "${2:-}"; MODEL="$2"; shift 2 ;;
    --target)
      require_arg "$1" "${2:-}"; TARGET="$2"; shift 2 ;;
    --tile)
      require_arg "$1" "${2:-}"; TILE="$2"; shift 2 ;;
    --gpu-id)
      require_arg "$1" "${2:-}"; GPU_ID="$2"; USER_GPU_ID_SET="1"; shift 2 ;;
    --allow-cpu)
      REQUIRE_GPU="0"; shift ;;
    --require-gpu)
      REQUIRE_GPU="1"; shift ;;
    --keep-frames)
      KEEP_FRAMES="1"; shift ;;
    -h|--help)
      usage; exit 0 ;;
    *)
      err "Unknown argument: $1"
      usage
      exit 1 ;;
  esac
done

[[ -n "$INPUT" ]] || { err "--in is required"; exit 2; }
[[ -n "$OUTPUT" ]] || { err "--out is required"; exit 2; }
[[ -f "$INPUT" ]] || { err "Input file not found: $INPUT"; exit 2; }
[[ "$SCALE" =~ ^(2|4)$ ]] || { err "--scale must be 2 or 4"; exit 2; }
[[ "$MODEL" =~ ^(realesrgan-x4plus|realesrgan-x4plus-anime)$ ]] || { err "--model unsupported: $MODEL"; exit 2; }
[[ "$TILE" =~ ^[0-9]+$ ]] || { err "--tile must be numeric"; exit 2; }
[[ "$GPU_ID" =~ ^[0-9]+$ ]] || { err "--gpu-id must be numeric"; exit 2; }
if [[ "$TARGET" == "none" || "$TARGET" == "off" ]]; then
  TARGET=""
fi
if [[ -n "$TARGET" ]]; then
  [[ "$TARGET" =~ ^[0-9]+x[0-9]+$ ]] || { err "--target must look like 1080x1920 (or use none)"; exit 2; }
fi

command -v ffmpeg >/dev/null 2>&1 || { err "ffmpeg not found"; exit 3; }
command -v ffprobe >/dev/null 2>&1 || { err "ffprobe not found"; exit 3; }
[[ -x "$REALESRGAN_BIN" ]] || { err "realesrgan-ncnn-vulkan not found at $REALESRGAN_BIN"; exit 3; }
[[ -d "$MODELS_DIR" ]] || { err "Models dir missing: $MODELS_DIR"; exit 3; }
[[ -f "$MODELS_DIR/${MODEL}.bin" ]] || { err "Model bin missing: $MODELS_DIR/${MODEL}.bin"; exit 3; }
[[ -f "$MODELS_DIR/${MODEL}.param" ]] || { err "Model param missing: $MODELS_DIR/${MODEL}.param"; exit 3; }

log "=== Environment checks ==="
NVSMI_OK="0"
if command -v nvidia-smi >/dev/null 2>&1; then
  NVSMI_OUT="$(nvidia-smi 2>&1 || true)"
  if echo "$NVSMI_OUT" | grep -Eiq 'failed|unknown error|no devices were found|couldn'"'"'t communicate|not found'; then
    warn "nvidia-smi reported a problem: $(echo "$NVSMI_OUT" | head -n 1)"
  else
    NVSMI_OK="1"
    GPU_NAME="$(nvidia-smi --query-gpu=name --format=csv,noheader 2>/dev/null | head -n 1 || true)"
    if [[ -n "$GPU_NAME" ]]; then
      log "nvidia-smi OK (GPU: $GPU_NAME)"
    else
      log "nvidia-smi OK"
    fi
  fi
else
  warn "nvidia-smi not found. NVIDIA runtime/driver may be unavailable."
fi

ensure_vulkaninfo() {
  if command -v vulkaninfo >/dev/null 2>&1; then
    return 0
  fi

  warn "vulkaninfo not found. Trying to install vulkan-tools..."
  if command -v apt-get >/dev/null 2>&1; then
    if [[ "${EUID}" -eq 0 ]]; then
      apt-get update -y >/dev/null 2>&1 || true
      apt-get install -y vulkan-tools >/dev/null 2>&1 || true
    elif command -v sudo >/dev/null 2>&1; then
      sudo apt-get update -y >/dev/null 2>&1 || true
      sudo apt-get install -y vulkan-tools >/dev/null 2>&1 || true
    fi
  fi

  if ! command -v vulkaninfo >/dev/null 2>&1; then
    warn "Could not install/find vulkaninfo."
    warn "Install manually with: apt-get update && apt-get install -y vulkan-tools"
    return 1
  fi
  return 0
}

if ensure_vulkaninfo; then
  VULKAN_OK="1"
  VULKAN_GPU_OK="0"
  HAS_LLVMPIPE="0"
  NVIDIA_ICD_BROKEN="0"
  DETECTED_GPU_ID=""
  VULKAN_TXT="$(mktemp)"
  if vulkaninfo --summary >"$VULKAN_TXT" 2>&1 || vulkaninfo >"$VULKAN_TXT" 2>&1; then
    if grep -Eiq 'deviceName[[:space:]]*=[[:space:]]*.*NVIDIA|PHYSICAL_DEVICE_TYPE_DISCRETE_GPU' "$VULKAN_TXT"; then
      VULKAN_GPU_OK="1"
    fi
    DETECTED_GPU_ID="$(awk '
      /^GPU[0-9]+:/ {
        g=$1
        sub(/^GPU/,"",g)
        sub(/:$/,"",g)
      }
      /deviceType[[:space:]]*=/ {
        dtype=$3
      }
      /deviceName[[:space:]]*=/ {
        name=substr($0, index($0, "=") + 2)
        if (name ~ /NVIDIA/ || dtype ~ /PHYSICAL_DEVICE_TYPE_DISCRETE_GPU/) {
          print g
          exit
        }
      }
    ' "$VULKAN_TXT")"
    if [[ -n "$DETECTED_GPU_ID" && "$USER_GPU_ID_SET" == "0" ]]; then
      GPU_ID="$DETECTED_GPU_ID"
      log "Auto-detected Vulkan GPU index: $GPU_ID"
    fi
    if grep -Eiq 'llvmpipe|software rasterizer|PHYSICAL_DEVICE_TYPE_CPU' "$VULKAN_TXT"; then
      HAS_LLVMPIPE="1"
      warn "Vulkan is using llvmpipe/software. Real-ESRGAN is running on CPU fallback."
      warn "In RunPod set NVIDIA_DRIVER_CAPABILITIES=graphics,utility,compute (or all), then restart the pod."
    else
      log "vulkaninfo OK (no llvmpipe detected)"
    fi
    if grep -Eiq "Could not get 'vkCreateInstance'|Failed to CreateInstance in ICD|libGLX_nvidia\\.so" "$VULKAN_TXT"; then
      NVIDIA_ICD_BROKEN="1"
      warn "NVIDIA Vulkan ICD failed to initialize. This usually means missing graphics driver capability in the container."
      warn "Set NVIDIA_DRIVER_CAPABILITIES to include graphics (or all) and restart RunPod."
    fi
  else
    VULKAN_OK="0"
    warn "vulkaninfo command failed. Vulkan runtime may be broken in this container."
    warn "In RunPod ensure GPU pod + NVIDIA_DRIVER_CAPABILITIES includes graphics (or all)."
  fi
  rm -f "$VULKAN_TXT"
else
  VULKAN_OK="0"
  VULKAN_GPU_OK="0"
  HAS_LLVMPIPE="1"
  NVIDIA_ICD_BROKEN="1"
fi

if [[ "$REQUIRE_GPU" == "1" ]]; then
  if [[ "$VULKAN_OK" != "1" || "$VULKAN_GPU_OK" != "1" || "$NVIDIA_ICD_BROKEN" == "1" ]]; then
    warn "GPU-only mode: Vulkan backend is unhealthy for Real-ESRGAN."
    warn "Trying CUDA GPU fallback scaler (still GPU-only, no CPU fallback)."
    HAS_AUDIO_FALLBACK="0"
    if ffprobe -v error -select_streams a:0 -show_entries stream=codec_type -of csv=p=0 "$INPUT" | grep -q 'audio'; then
      HAS_AUDIO_FALLBACK="1"
    fi
    if run_cuda_fallback "$INPUT" "$OUTPUT" "$SCALE" "$TARGET" "$HAS_AUDIO_FALLBACK"; then
      exit 0
    fi
    err "GPU-only mode failed: Vulkan backend unavailable and CUDA fallback failed."
    err "Fix RunPod GPU runtime (graphics capability + proper device mapping) and retry."
    exit 40
  fi
  if [[ "$NVSMI_OK" != "1" ]]; then
    warn "nvidia-smi is unhealthy, continuing because Vulkan GPU appears present."
  fi
fi
log "Using GPU index for Real-ESRGAN: $GPU_ID"

if [[ "$REQUIRE_GPU" == "1" ]]; then
  log "Running GPU backend probe (CPU forbidden)..."
  PROBE_DIR="$(mktemp -d /tmp/realesrgan_probe_XXXXXX)"
  PROBE_IN="${PROBE_DIR}/in.png"
  PROBE_OUT="${PROBE_DIR}/out.png"
  PROBE_LOG="${PROBE_DIR}/probe.log"
  ffmpeg -hide_banner -loglevel error -y -f lavfi -i color=size=8x8:rate=1:color=black -frames:v 1 "$PROBE_IN"
  if ! "$REALESRGAN_BIN" \
    -i "$PROBE_IN" \
    -o "$PROBE_OUT" \
    -m "$MODELS_DIR" \
    -n "$MODEL" \
    -s 2 \
    -t 32 \
    -g "$GPU_ID" \
    -f png >"$PROBE_LOG" 2>&1; then
    err "GPU probe failed. Real-ESRGAN could not run on requested Vulkan GPU."
    rm -rf "$PROBE_DIR"
    exit 42
  fi
  if grep -Eiq 'llvmpipe|software rasterizer|PHYSICAL_DEVICE_TYPE_CPU' "$PROBE_LOG"; then
    err "GPU probe detected CPU fallback (llvmpipe). Aborting because CPU is forbidden."
    rm -rf "$PROBE_DIR"
    exit 43
  fi
  rm -rf "$PROBE_DIR"
  log "GPU backend probe passed."
fi

FPS_RAW="$(ffprobe -v error -select_streams v:0 -show_entries stream=avg_frame_rate -of default=nw=1:nk=1 "$INPUT" || true)"
if [[ -z "$FPS_RAW" || "$FPS_RAW" == "0/0" || "$FPS_RAW" == "N/A" ]]; then
  FPS_RAW="$(ffprobe -v error -select_streams v:0 -show_entries stream=r_frame_rate -of default=nw=1:nk=1 "$INPUT" || true)"
fi
FPS="$(awk -v r="$FPS_RAW" 'BEGIN{split(r,a,"/"); if (a[2]=="" || a[2]==0) {print r} else {printf "%.6f", a[1]/a[2]}}')"
[[ -n "$FPS" ]] || { err "Could not detect FPS from input"; exit 4; }
log "Input FPS: $FPS (raw: $FPS_RAW)"

HAS_AUDIO="0"
if ffprobe -v error -select_streams a:0 -show_entries stream=codec_type -of csv=p=0 "$INPUT" | grep -q 'audio'; then
  HAS_AUDIO="1"
  log "Audio stream detected and will be copied"
else
  log "No audio stream detected"
fi

WORKDIR="$(mktemp -d /tmp/realesrgan_upscale_XXXXXX)"
FRAMES_IN="${WORKDIR}/frames_in"
FRAMES_UP="${WORKDIR}/frames_up"
mkdir -p "$FRAMES_IN" "$FRAMES_UP"

cleanup() {
  if [[ "$KEEP_FRAMES" == "1" ]]; then
    log "Keeping frames at: $WORKDIR"
  else
    rm -rf "$WORKDIR"
  fi
}
trap cleanup EXIT

log "Extracting frames..."
ffmpeg -hide_banner -loglevel error -y -i "$INPUT" -vsync 0 "${FRAMES_IN}/frame_%08d.png"

IN_COUNT="$(find "$FRAMES_IN" -maxdepth 1 -type f -name 'frame_*.png' | wc -l | tr -d ' ')"
[[ "$IN_COUNT" -gt 0 ]] || { err "No input frames extracted"; exit 5; }
log "Extracted frames: $IN_COUNT"

log "Upscaling with Real-ESRGAN..."
RG_LOG="$(mktemp)"
if ! "$REALESRGAN_BIN" \
  -i "$FRAMES_IN" \
  -o "$FRAMES_UP" \
  -m "$MODELS_DIR" \
  -n "$MODEL" \
  -s "$SCALE" \
  -t "$TILE" \
  -g "$GPU_ID" \
  -f png 2>&1 | tee "$RG_LOG"; then
  err "Real-ESRGAN execution failed"
  rm -f "$RG_LOG"
  exit 6
fi
if [[ "$REQUIRE_GPU" == "1" ]] && grep -Eiq 'llvmpipe|software rasterizer|PHYSICAL_DEVICE_TYPE_CPU' "$RG_LOG"; then
  err "CPU fallback detected in Real-ESRGAN output while GPU-only mode is enabled."
  err "RunPod fix needed: set NVIDIA_DRIVER_CAPABILITIES=graphics,utility,compute (or all), restart pod."
  rm -f "$RG_LOG"
  exit 41
fi
rm -f "$RG_LOG"

OUT_COUNT="$(find "$FRAMES_UP" -maxdepth 1 -type f -name 'frame_*.png' | wc -l | tr -d ' ')"
[[ "$OUT_COUNT" -gt 0 ]] || { err "No upscaled frames generated (frames_out empty)"; exit 6; }
if [[ "$OUT_COUNT" -ne "$IN_COUNT" ]]; then
  warn "Frame count mismatch: input=${IN_COUNT}, upscaled=${OUT_COUNT}"
fi
log "Upscaled frames: $OUT_COUNT"

VF_ARGS=()
if [[ -n "$TARGET" ]]; then
  TARGET_W="${TARGET%x*}"
  TARGET_H="${TARGET#*x}"
  VF_ARGS=( -vf "scale=${TARGET_W}:${TARGET_H}:force_original_aspect_ratio=decrease:flags=lanczos,pad=${TARGET_W}:${TARGET_H}:(ow-iw)/2:(oh-ih)/2:black" )
  log "Applying target canvas: ${TARGET_W}x${TARGET_H}"
else
  log "No target resize requested; keeping pure x${SCALE} dimensions"
fi

log "Encoding output video..."
if [[ "$HAS_AUDIO" == "1" ]]; then
  if ! ffmpeg -hide_banner -loglevel error -y \
    -framerate "$FPS" -i "${FRAMES_UP}/frame_%08d.png" \
    -i "$INPUT" \
    -map 0:v:0 -map 1:a:0 \
    -c:v libx264 -preset medium -crf 18 -pix_fmt yuv420p \
    "${VF_ARGS[@]}" \
    -c:a copy -shortest \
    "$OUTPUT"; then
    warn "Audio copy failed for this container/format. Retrying with AAC re-encode."
    ffmpeg -hide_banner -loglevel error -y \
      -framerate "$FPS" -i "${FRAMES_UP}/frame_%08d.png" \
      -i "$INPUT" \
      -map 0:v:0 -map 1:a:0 \
      -c:v libx264 -preset medium -crf 18 -pix_fmt yuv420p \
      "${VF_ARGS[@]}" \
      -c:a aac -b:a 192k -shortest \
      "$OUTPUT"
  fi
else
  ffmpeg -hide_banner -loglevel error -y \
    -framerate "$FPS" -i "${FRAMES_UP}/frame_%08d.png" \
    -map 0:v:0 \
    -c:v libx264 -preset medium -crf 18 -pix_fmt yuv420p \
    "${VF_ARGS[@]}" \
    "$OUTPUT"
fi

[[ -f "$OUTPUT" ]] || { err "Output was not created: $OUTPUT"; exit 7; }
log "Done: $OUTPUT"
