#!/usr/bin/env bash
set -euo pipefail

log() { printf '[%s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*"; }
err() { printf '[%s] ERROR: %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*" >&2; }

if [[ "${EUID}" -ne 0 ]]; then
  err "Run as root: sudo bash /workspace/realesrgan_gpu_pack/setup_ai_cuda.sh"
  exit 1
fi

export DEBIAN_FRONTEND=noninteractive
BASE_DIR="/workspace/tools/realesrgan_ai"
REPO_DIR="${BASE_DIR}/Real-ESRGAN"
VENV_DIR="${BASE_DIR}/venv"

mkdir -p "$BASE_DIR"

log "Installing apt packages..."
apt-get update -y
apt-get install -y git ffmpeg python3-venv python3-pip

if [[ ! -d "$REPO_DIR/.git" ]]; then
  log "Cloning Real-ESRGAN repo..."
  git clone --depth 1 https://github.com/xinntao/Real-ESRGAN.git "$REPO_DIR"
else
  log "Using existing repo: $REPO_DIR"
fi

if [[ ! -d "$VENV_DIR" ]]; then
  log "Creating venv..."
  python3 -m venv "$VENV_DIR"
fi

source "${VENV_DIR}/bin/activate"
python -m pip install --upgrade pip setuptools wheel

log "Installing PyTorch CUDA wheels..."
python -m pip install --index-url https://download.pytorch.org/whl/cu124 torch torchvision

log "Installing Real-ESRGAN dependencies..."
cd "$REPO_DIR"
python -m pip install -r requirements.txt
python -m pip install -e .

log "Applying torchvision compatibility shim (functional_tensor)..."
python - <<'PY'
from pathlib import Path
import importlib
import torchvision

transforms_dir = Path(torchvision.__file__).resolve().parent / "transforms"
shim = transforms_dir / "functional_tensor.py"
if not shim.exists():
    shim.write_text(
        "# Auto-generated compatibility shim for BasicSR on newer torchvision\n"
        "from .functional import *\n",
        encoding="utf-8",
    )
    print("Created:", shim)
else:
    print("Already present:", shim)
PY

log "Checking CUDA availability in torch..."
python - <<'PY'
import torch, sys
print("torch:", torch.__version__)
print("cuda_available:", torch.cuda.is_available())
print("device_count:", torch.cuda.device_count())
if not torch.cuda.is_available():
    print("ERROR: torch CUDA is not available in this pod")
    sys.exit(2)
print("device0:", torch.cuda.get_device_name(0))
PY

log "Setup complete."
log "Next: bash /workspace/realesrgan_gpu_pack/upscale_video_ai_cuda.sh --in /workspace/edit.mp4 --out /workspace/output_ai_1080.mp4 --model x2 --target 1080x1920"
