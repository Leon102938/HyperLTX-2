#!/usr/bin/env bash
set -euo pipefail

HAS_NVIDIA=0
HAS_NVENC=0
HAS_VULKAN=0
VULKAN_BROKEN=0
VULKAN_CPU_FALLBACK=0
ENV_VOID=0

match() {
  local pattern="$1"
  local file="$2"
  grep -Eiq "$pattern" "$file"
}

print_matches() {
  local pattern="$1"
  local file="$2"
  grep -Ei "$pattern" "$file" || true
}

echo "=== ENV ==="
echo "NVIDIA_VISIBLE_DEVICES=${NVIDIA_VISIBLE_DEVICES-<unset>}"
echo "NVIDIA_DRIVER_CAPABILITIES=${NVIDIA_DRIVER_CAPABILITIES-<unset>}"
if [[ "${NVIDIA_VISIBLE_DEVICES-}" == "void" ]]; then
  ENV_VOID=1
fi
echo

echo "=== DEVICES ==="
ls -la /dev/nvidia* 2>/dev/null || true
echo

echo "=== NVIDIA-SMI ==="
if nvidia-smi >/tmp/pod_smoke_nvidia.log 2>&1; then
  echo "OK: nvidia-smi"
  HAS_NVIDIA=1
else
  echo "FAIL: nvidia-smi"
  sed -n '1,60p' /tmp/pod_smoke_nvidia.log || true
fi
echo

echo "=== NVENC ==="
if ffmpeg -hide_banner -loglevel error -y \
  -f lavfi -i testsrc=size=320x180:rate=30 -t 1 \
  -c:v h264_nvenc -an /tmp/pod_smoke_nvenc.mp4; then
  echo "OK: h264_nvenc"
  HAS_NVENC=1
else
  echo "FAIL: h264_nvenc"
fi
echo

echo "=== VULKAN ==="
if command -v vulkaninfo >/dev/null 2>&1; then
  vulkaninfo --summary > /tmp/pod_smoke_vulkan.log 2>&1 || true
  print_matches "deviceName|deviceType|llvmpipe|nvidia|Failed to CreateInstance|vkCreateInstance|ERROR_INCOMPATIBLE_DRIVER" /tmp/pod_smoke_vulkan.log
  HAS_VULKAN=1
  if match "Failed to CreateInstance|vkCreateInstance|ERROR_INCOMPATIBLE_DRIVER|Could not get 'vkCreateInstance'" /tmp/pod_smoke_vulkan.log; then
    VULKAN_BROKEN=1
  fi
  if match "llvmpipe|software rasterizer|PHYSICAL_DEVICE_TYPE_CPU" /tmp/pod_smoke_vulkan.log; then
    VULKAN_CPU_FALLBACK=1
  fi
else
  echo "vulkaninfo not installed"
fi
echo

echo "=== RESULT ==="
if [[ "$HAS_NVIDIA" != "1" ]]; then
  echo "BAD: GPU runtime broken (nvidia-smi failed)"
  exit 1
fi

if [[ "$HAS_NVENC" != "1" ]]; then
  echo "BAD: CUDA/NVENC path broken (no CUDA-capable device)"
  exit 2
fi

if [[ "$HAS_VULKAN" != "1" ]]; then
  if [[ "$ENV_VOID" == "1" ]]; then
    echo "WARN: NVIDIA_VISIBLE_DEVICES=void, but CUDA/NVENC works on this pod."
  fi
  echo "GOOD (CUDA path): nvidia-smi + NVENC are healthy. Vulkan was not tested."
  echo "Install vulkan-tools only if you need Real-ESRGAN-ncnn-vulkan."
  exit 0
fi

if [[ "$VULKAN_BROKEN" == "1" || "$VULKAN_CPU_FALLBACK" == "1" ]]; then
  if [[ "$ENV_VOID" == "1" ]]; then
    echo "WARN: NVIDIA_VISIBLE_DEVICES=void and Vulkan broken."
  fi
  echo "PARTIAL: CUDA/NVENC works, Vulkan path broken."
  echo "Use CUDA-based upscale workflow, not Vulkan-ncnn."
  exit 3
fi

if [[ "$ENV_VOID" == "1" ]]; then
  echo "WARN: NVIDIA_VISIBLE_DEVICES=void, but runtime checks passed."
fi
echo "GOOD: Vulkan + NVIDIA look healthy"
echo "You can run Real-ESRGAN-ncnn-vulkan on GPU"
