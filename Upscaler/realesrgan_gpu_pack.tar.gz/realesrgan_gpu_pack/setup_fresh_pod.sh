#!/usr/bin/env bash
set -euo pipefail

log()  { printf '[%s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*"; }
warn() { printf '[%s] WARN: %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*" >&2; }
err()  { printf '[%s] ERROR: %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*" >&2; }

require_root() {
  if [[ "${EUID}" -ne 0 ]]; then
    err "Run as root: sudo bash /workspace/realesrgan_gpu_pack/setup_fresh_pod.sh"
    exit 1
  fi
}

assert_file() {
  local p="$1"
  [[ -f "$p" ]] || { err "Missing file: $p"; exit 1; }
}

require_root
export DEBIAN_FRONTEND=noninteractive

PACK_DIR="/workspace/realesrgan_gpu_pack"
TOOLS_DIR="/workspace/tools/realesrgan"
MODELS_DIR="${TOOLS_DIR}/models"
BIN_DST="/usr/local/bin/realesrgan-ncnn-vulkan"
ZIP_URL="https://github.com/xinntao/Real-ESRGAN/releases/download/v0.2.5.0/realesrgan-ncnn-vulkan-20220424-ubuntu.zip"
ZIP_PATH="${TOOLS_DIR}/realesrgan-ncnn-vulkan-20220424-ubuntu.zip"
VULKAN_LOG="/tmp/realesrgan_vulkan_probe.log"
STRICT_VULKAN="${STRICT_VULKAN:-0}"

mkdir -p "$PACK_DIR" "$TOOLS_DIR" "$MODELS_DIR"

log "Installing system packages..."
apt-get update -y
apt-get install -y ffmpeg curl unzip ca-certificates vulkan-tools

# Some containers expose only /dev/nvidia1. Add alias expected by tooling.
if [[ ! -e /dev/nvidia0 && -e /dev/nvidia1 ]]; then
  ln -sf /dev/nvidia1 /dev/nvidia0 || true
fi

if [[ "${NVIDIA_VISIBLE_DEVICES:-}" == "void" ]]; then
  warn "NVIDIA_VISIBLE_DEVICES=void detected. Some runtimes still work with CUDA/NVENC."
  warn "If Vulkan fails, use CUDA fallback path in /workspace/upscale_video.sh."
fi

log "Checking NVIDIA runtime..."
if ! nvidia-smi >/tmp/realesrgan_nvidia_smi.log 2>&1; then
  err "nvidia-smi failed."
  sed -n '1,80p' /tmp/realesrgan_nvidia_smi.log >&2 || true
  err "Fix pod runtime first (GPU mapping)."
  exit 11
fi

log "Checking NVENC..."
if ! ffmpeg -hide_banner -loglevel error -y \
  -f lavfi -i testsrc=size=320x180:rate=30 -t 1 \
  -c:v h264_nvenc -an /tmp/realesrgan_nvenc_probe.mp4; then
  err "NVENC probe failed. GPU encode path not healthy."
  exit 12
fi

probe_vulkan() {
  local icd_file="${1:-}"
  if [[ -n "$icd_file" ]]; then
    VK_ICD_FILENAMES="$icd_file" vulkaninfo --summary >"$VULKAN_LOG" 2>&1 || return 1
  else
    vulkaninfo --summary >"$VULKAN_LOG" 2>&1 || return 1
  fi

  if grep -Eiq "Could not get 'vkCreateInstance'|Failed to CreateInstance in ICD|ERROR_INCOMPATIBLE_DRIVER" "$VULKAN_LOG"; then
    return 2
  fi
  if grep -Eiq 'llvmpipe|software rasterizer|PHYSICAL_DEVICE_TYPE_CPU' "$VULKAN_LOG"; then
    return 3
  fi
  if ! grep -Eiq 'deviceName[[:space:]]*=[[:space:]]*.*NVIDIA|PHYSICAL_DEVICE_TYPE_DISCRETE_GPU' "$VULKAN_LOG"; then
    return 4
  fi
  return 0
}

VULKAN_OK=0
log "Checking Vulkan NVIDIA ICD..."
if probe_vulkan ""; then
  VULKAN_OK=1
else
  warn "Default Vulkan probe failed. Retrying with explicit NVIDIA ICD..."
  if [[ -f /etc/vulkan/icd.d/nvidia_icd.json ]]; then
    if probe_vulkan "/etc/vulkan/icd.d/nvidia_icd.json"; then
      VULKAN_OK=1
    fi
  fi
fi

if [[ "$VULKAN_OK" != "1" ]]; then
  if [[ "$STRICT_VULKAN" == "1" ]]; then
    err "Vulkan NVIDIA probe failed and STRICT_VULKAN=1."
    sed -n '1,160p' "$VULKAN_LOG" >&2 || true
    exit 13
  fi
  warn "Vulkan NVIDIA probe failed."
  warn "Real-ESRGAN ncnn Vulkan path may not work on this pod."
  warn "The provided /workspace/upscale_video.sh will use CUDA fallback when needed."
fi

log "Downloading Real-ESRGAN ncnn Vulkan..."
if [[ ! -f "$ZIP_PATH" ]]; then
  curl -L --fail --retry 3 -o "$ZIP_PATH" "$ZIP_URL"
else
  log "Using cached archive: $ZIP_PATH"
fi

log "Extracting archive..."
unzip -o "$ZIP_PATH" -d "$TOOLS_DIR" >/tmp/realesrgan_unzip.log

assert_file "${TOOLS_DIR}/realesrgan-ncnn-vulkan"
install -m 0755 -D "${TOOLS_DIR}/realesrgan-ncnn-vulkan" "$BIN_DST"

for f in \
  "realesrgan-x4plus.param" \
  "realesrgan-x4plus.bin" \
  "realesrgan-x4plus-anime.param" \
  "realesrgan-x4plus-anime.bin"
do
  assert_file "${MODELS_DIR}/${f}"
done

assert_file "${PACK_DIR}/upscale_video.sh"
cp -f "${PACK_DIR}/upscale_video.sh" /workspace/upscale_video.sh
chmod +x /workspace/upscale_video.sh

log "Setup finished."
if [[ "$VULKAN_OK" == "1" ]]; then
  log "Vulkan status: OK (Real-ESRGAN Vulkan path should work)"
else
  log "Vulkan status: FAIL (CUDA fallback mode)"
fi
log "Run test:"
printf '%s\n' \
  "/workspace/upscale_video.sh --in /workspace/edit.mp4 --out /workspace/output_upscaled.mp4 --scale 2 --model realesrgan-x4plus --target none --tile 0"
