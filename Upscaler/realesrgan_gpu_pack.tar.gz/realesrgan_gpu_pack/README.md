# RealESRGAN GPU Pack (RunPod) - Full Guide

This pack gives you two working paths:

1. `Vulkan ncnn path` (fast native binary, needs healthy Vulkan NVIDIA ICD)
2. `CUDA AI path` (PyTorch CUDA, no Vulkan required, recommended when Vulkan is broken)

For your case (TikTok 9:16, fast, AI quality), use **CUDA AI path**.

---

## 1) Files in this pack

- `setup_fresh_pod.sh`
  - installs ffmpeg + realesrgan-ncnn-vulkan
  - checks NVIDIA/NVENC/Vulkan
  - keeps working even if Vulkan is broken (with warnings)
- `upscale_video.sh`
  - primary script
  - tries Vulkan AI first; if Vulkan broken, uses CUDA resize fallback
- `setup_ai_cuda.sh`
  - installs Real-ESRGAN PyTorch + CUDA (AI path without Vulkan)
- `upscale_video_ai_cuda.sh`
  - real AI upscaling via PyTorch CUDA (recommended)
- `pod_gpu_smoke_test.sh`
  - quick health check for pod GPU runtime
- `app/upscaler_api.py` integration
  - API backend used by `/upscale/video` in FastAPI
  - now wired to AI CUDA path (not Vulkan fallback)

---

## 2) Fresh Pod - exact steps

Use `bash` shell (not `sh`) for these commands.

```bash
cd /workspace
tar -xzf realesrgan_gpu_pack.tar.gz

# Apply API patch into /workspace/app
bash /workspace/realesrgan_gpu_pack/apply_app_patch.sh

# Optional quick health check
bash /workspace/realesrgan_gpu_pack/pod_gpu_smoke_test.sh; echo EXIT:$?
```

Interpretation:
- `EXIT:0` -> NVIDIA + Vulkan healthy
- `EXIT:3` -> CUDA/NVENC works, Vulkan broken (still usable via CUDA AI path)
- `EXIT:1/2/4` -> runtime unhealthy

### Install AI CUDA path (recommended)

```bash
bash /workspace/realesrgan_gpu_pack/setup_ai_cuda.sh
```

### Run AI upscale for TikTok format

```bash
bash /workspace/realesrgan_gpu_pack/upscale_video_ai_cuda.sh \
  --in /workspace/edit.mp4 \
  --out /workspace/output_tiktok_1080x1920.mp4 \
  --model x2 \
  --target 1080x1920 \
  --tile 0
```

---

## 3) Your exact scenario (576x1024 -> TikTok)

Input is portrait 9:16.  
Best output target: `1080x1920`.

Recommended command:

```bash
bash /workspace/realesrgan_gpu_pack/upscale_video_ai_cuda.sh \
  --in /workspace/edit.mp4 \
  --out /workspace/output_tiktok_1080x1920.mp4 \
  --model x2 \
  --target 1080x1920 \
  --tile 0
```

Why this is best:
- `x2` is ideal from 576x1024 to around 1152x2048 quality domain
- then downfit to exact 1080x1920
- best quality/speed balance for short-form vertical videos

---

## 4) Why `--tile 0` still might feel "not faster"

Important points:

1. `tile=0` only disables tiling overhead.  
   AI inference can still be heavy per frame.
2. RealESRGAN PyTorch inference is frame-by-frame (not huge batch video inference).
3. 12 seconds at 30 fps = ~360 frames.  
   Even if each frame is fast, total time can still be minutes.
4. First run can be slower due model download/load and cache warmup.

### How to confirm whether tiling is active

If log prints lines like:
- `Tile 1/40`, `Tile 2/40`, ...

then tiling is active (tile not 0 or old command/script path).

If tile is truly 0, those `Tile N/M` lines should disappear.

---

## 5) Speed tuning profiles

### A) Fastest AI (good quality)

```bash
bash /workspace/realesrgan_gpu_pack/upscale_video_ai_cuda.sh \
  --in /workspace/edit.mp4 \
  --out /workspace/out_fast_ai.mp4 \
  --model x2 \
  --target 1080x1920 \
  --tile 0
```

### B) If out-of-memory or instability

Use tiles:
- `--tile 768`
- or `--tile 512`

### C) Maximum speed without AI (not recommended for quality)

Use:
- `upscale_video.sh` fallback path (CUDA resize)

This is fast but quality gain is much lower than AI.

---

## 6) Script reference

### `upscale_video_ai_cuda.sh` flags

- `--in` input video path (required)
- `--out` output video path (required)
- `--model`:
  - `x2` (recommended default)
  - `x4`
  - `anime`
- `--target`:
  - `1080x1920` for TikTok
  - `none` to keep model-native scale output
- `--tile`:
  - `0` fastest if VRAM allows
  - `256/512/768` safer VRAM usage
- `--keep-frames`:
  - keep temporary extracted/upscaled frame folders

---

## 7) Verification commands

### Check output resolution/fps

```bash
ffprobe -v error -show_entries stream=width,height,avg_frame_rate -of default=nw=1 /workspace/output_tiktok_1080x1920.mp4
```

### Create quick side-by-side compare

```bash
ffmpeg -y -i /workspace/edit.mp4 -i /workspace/output_tiktok_1080x1920.mp4 \
  -filter_complex "[0:v]scale=540:960[left];[1:v]scale=540:960[right];[left][right]hstack=inputs=2[v]" \
  -map "[v]" -c:v libx264 -pix_fmt yuv420p /workspace/compare_before_after.mp4
```

---

## 8) Troubleshooting (common)

### Error: `ModuleNotFoundError: torchvision.transforms.functional_tensor`

Fix:

```bash
. /workspace/tools/realesrgan_ai/venv/bin/activate
printf "from .functional import *\n" > /workspace/tools/realesrgan_ai/venv/lib/python3.12/site-packages/torchvision/transforms/functional_tensor.py
```

Then rerun AI upscale command.

---

### `source: not found`

You are in `sh`, not `bash`. Use:

```sh
. /workspace/tools/realesrgan_ai/venv/bin/activate
```

---

### `NVIDIA_VISIBLE_DEVICES=void`

If `nvidia-smi` + `h264_nvenc` are both OK, CUDA path can still work.  
If CUDA tests fail, pod runtime is bad: recreate pod on another host/zone/template.

---

### Vulkan errors (`llvmpipe`, `vkCreateInstance`)

Ignore for CUDA AI path.  
Vulkan only matters for `realesrgan-ncnn-vulkan` binary path.

---

## 9) Minimal "do this only" block

If you want just one reliable flow:

```bash
cd /workspace
tar -xzf realesrgan_gpu_pack.tar.gz
bash /workspace/realesrgan_gpu_pack/setup_ai_cuda.sh
bash /workspace/realesrgan_gpu_pack/upscale_video_ai_cuda.sh --in /workspace/edit.mp4 --out /workspace/output_tiktok_1080x1920.mp4 --model x2 --target 1080x1920 --tile 0
```

This is the recommended open-source AI path for your current RunPod conditions.

---

## 10) n8n + API usage

Endpoint in your app:

`POST /upscale/video`

This route is already defined in `app/main.py` and calls `app/upscaler_api.py`.

### n8n HTTP Request node settings

- Method: `POST`
- URL: `http://<pod-host>:8000/upscale/video`
- Content-Type: `application/json`
- Send Body: `JSON`

### Recommended JSON body (TikTok 9:16 AI upscale)

```json
{
  "input_path": "edit.mp4",
  "output_name": "output_tiktok_1080x1920.mp4",
  "model": "x2",
  "target": "1080x1920",
  "tile": 0,
  "dry_run": false
}
```

### Legacy-compatible body (CLI-like naming)

```json
{
  "in": "edit.mp4",
  "out": "exports/output_tiktok_1080x1920.mp4",
  "model": "realesrgan-x4plus",
  "scale": 2,
  "target": "1080x1920",
  "tile": 0
}
```

Notes:
- `model` mapping:
  - `x2` or `realesrgan-x2plus` -> AI model `x2`
  - `x4` or `realesrgan-x4plus` -> AI model `x4`
  - contains `anime` -> AI model `anime`
- `dry_run=true` returns resolved command and paths without running heavy inference.

### Curl smoke tests

Dry-run (fast):

```bash
curl -sS -X POST "http://127.0.0.1:8000/upscale/video" \
  -H "Content-Type: application/json" \
  -d '{"input_path":"edit.mp4","output_name":"smoke.mp4","model":"x2","target":"1080x1920","tile":0,"dry_run":true}'
```

Real run:

```bash
curl -sS -X POST "http://127.0.0.1:8000/upscale/video" \
  -H "Content-Type: application/json" \
  -d '{"input_path":"edit.mp4","output_name":"output_tiktok_1080x1920.mp4","model":"x2","target":"1080x1920","tile":0}'
```
