#!/usr/bin/env bash
set -euo pipefail

SRC="/workspace/realesrgan_gpu_pack/app/upscaler_api.py"
DST="/workspace/app/upscaler_api.py"

if [[ ! -f "$SRC" ]]; then
  echo "ERROR: missing source file: $SRC" >&2
  exit 1
fi

cp -f "$SRC" "$DST"
python3 -m py_compile "$DST"
echo "Patched: $DST"
